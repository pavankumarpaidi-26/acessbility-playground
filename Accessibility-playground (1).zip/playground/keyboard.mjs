import puppeteer from "puppeteer-core";
import assert from "node:assert/strict";
const browser = await puppeteer.launch({
  executablePath: process.env.CHROME_PATH,
  args: ["--no-sandbox"],
  headless: true,
});
try {
  const p = await browser.newPage();
  await p.goto(process.env.TEST_URL || "http://localhost:4180");
  await p.waitForSelector(".action");
  const press = (k) => p.keyboard.press(k),
    active = () => p.evaluate(() => document.activeElement.textContent.trim()),
    expect = async (s) => assert.equal(await active(), s);
  await press("Tab");
  await expect("Open specimen ↗");
  await press("Enter");
  await expect("Close dialog");
  await p.keyboard.down("Shift"); await press("Tab"); await p.keyboard.up("Shift");
  await expect("Done");
  await press("Tab");
  await expect("Close dialog");
  await press("Escape");
  await expect("Open specimen ↗");
  await press("Enter");
  await press("Tab");
  await press("Enter");
  await expect("Open specimen ↗");
  console.log(
    "PASS: dialog initial focus, both wrap directions, Escape and Done restore opener",
  );
  await press("Tab");
  await expect("Overview");
  for (const [k, t] of [
    ["ArrowLeft", "Focus"],
    ["ArrowRight", "Overview"],
    ["End", "Focus"],
    ["Home", "Overview"],
    ["ArrowRight", "Keyboard"],
  ]) {
    await press(k);
    await expect(t);
    assert.equal(
      await p.evaluate(() =>
        document.activeElement.getAttribute("aria-selected"),
      ),
      "true",
    );
  }
  await press("Tab");
  assert.equal(
    await p.evaluate(() => document.activeElement.getAttribute("role")),
    "tabpanel",
  );
  console.log("PASS: tabs wrap, select, Home/End and Tab to active panel");
  await press("Tab");
  for (const [k, state] of [
    ["Space", "true"],
    ["Enter", "false"],
  ]) {
    await press(k);
    assert.equal(
      await p.evaluate(() =>
        document.activeElement.getAttribute("aria-expanded"),
      ),
      state,
    );
    assert.equal(await p.$eval(".note", (n) => n.hidden), state === "false");
  }
  console.log(
    "PASS: disclosure toggles with Space and Enter without moving focus",
  );
} finally {
  await browser.close();
}
