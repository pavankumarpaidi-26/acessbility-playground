import { useId, useRef } from "react";
export function Modal() {
  const dialog = useRef<HTMLDialogElement>(null),
    trigger = useRef<HTMLButtonElement>(null),
    first = useRef<HTMLButtonElement>(null),
    last = useRef<HTMLButtonElement>(null),
    id = useId();
  return (
    <>
      <button
        className="action"
        ref={trigger}
        onClick={() => {
          dialog.current?.showModal();
          first.current?.focus();
        }}
      >
        Open specimen ↗
      </button>
      <dialog
        ref={dialog}
        aria-modal="true"
        aria-labelledby={id}
        aria-describedby={id + "-desc"}
        onClose={() => { if (document.activeElement === document.body || dialog.current?.contains(document.activeElement)) trigger.current?.focus(); }}
        onKeyDown={(e) => {
          if (e.key !== "Tab") return;
          const edge = e.shiftKey ? first : last;
          if (document.activeElement === edge.current) {
            e.preventDefault();
            (e.shiftKey ? last : first).current?.focus();
          }
        }}
      >
        <small>SPECIMEN 01 / DIALOG</small>
        <h2 id={id}>Inside the dialog</h2>
        <p id={id + "-desc"}>
          Tab cycles between these two controls. Escape returns you to the
          opener.
        </p>
        <div className="actions">
          <button ref={first} onClick={() => dialog.current?.close()}>
            Close dialog
          </button>
          <button ref={last} onClick={() => dialog.current?.close()}>
            Done
          </button>
        </div>
      </dialog>
    </>
  );
}
