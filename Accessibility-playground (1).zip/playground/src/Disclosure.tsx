import { useId, useState, type ReactNode } from "react";
export function Disclosure({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  const [open, set] = useState(false),
    id = useId();
  return (
    <>
      <button
        className="disclose"
        aria-expanded={open}
        aria-controls={id}
        onClick={() => set(!open)}
      >
        {label}
        <span aria-hidden="true">{open ? "−" : "+"}</span>
      </button>
      <div className="note" hidden={!open} id={id}>
        {children}
      </div>
    </>
  );
}
