import { createRoot } from "react-dom/client";
import { Modal } from "./Dialog";
import { Tabs as HandmadeTabs } from "./Tabs";
import { Disclosure } from "./Disclosure";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./components/ui/tabs";
import "./style.css";
function App() {
  return (
    <main>
      <header>
        <b>⌘ &nbsp; Interface Studies</b>
        <small>FOUNDATIONS / LAB 03</small>
      </header>
      <div className="intro">
        <small>FIELD MANUAL &nbsp; / &nbsp; ACCESSIBILITY</small>
        <h1>
          Interaction Atlas<span>.</span>
        </h1>
        <p>
          Three keyboard-first patterns. Try each specimen without a mouse, then
          compare the reference implementation.
        </p>
      </div>
      <section>
        <small>01 / FOCUS BOUNDARY</small>
        <h2>Modal dialog</h2>
        <p>Enter a separate context, then return to your starting point.</p>
        <Modal />
      </section>
      <section>
        <small>02 / ROVING FOCUS</small>
        <h2>Tabs</h2>
        <HandmadeTabs
          items={[
            {
              title: "Overview",
              body: "One tab stop enters the group. The selected tab reveals its panel.",
            },
            {
              title: "Keyboard",
              body: "Use Left or Right to wrap through the tabs. Home and End jump to either edge.",
            },
            {
              title: "Focus",
              body: "Tab moves from the selected tab to its panel, then onward.",
            },
          ]}
        />
      </section>
      <section>
        <small>03 / PROGRESSIVE DETAIL</small>
        <h2>Disclosure</h2>
        <Disclosure label="Show keyboard guidance">
          Enter or Space toggles this note. Focus stays on the button.
        </Disclosure>
      </section>
      <section>
        <small>04 / REFERENCE BENCH</small>
        <h2>shadcn/ui comparison</h2>
        <Dialog>
          <DialogTrigger className="action">
            Open reference dialog
          </DialogTrigger>
          <DialogContent>
            <DialogTitle>Reference dialog</DialogTitle>
            <DialogDescription>
              Inspect the portal, close control and restored focus.
            </DialogDescription>
          </DialogContent>
        </Dialog>
        <Tabs defaultValue="one">
          <TabsList aria-label="Reference notes">
            <TabsTrigger value="one">Radix</TabsTrigger>
            <TabsTrigger value="two">Composition</TabsTrigger>
          </TabsList>
          <TabsContent value="one">
            Radix primitives provide the interaction model.
          </TabsContent>
          <TabsContent value="two">
            Generated wrappers add presentation and compose the close button.
          </TabsContent>
        </Tabs>
      </section>
      <footer>INTERFACE STUDIES &nbsp; / &nbsp; END OF FIELD NOTES</footer>
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
