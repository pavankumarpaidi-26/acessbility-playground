import { useId, useRef, useState } from "react";
export type TabItem = { title: string; body: string };
export function Tabs({ items }: { items: readonly [TabItem, ...TabItem[]] }) {
  const id = useId(),
    [active, set] = useState(0),
    refs = useRef<(HTMLButtonElement | null)[]>([]);
  return (
    <>
      <div role="tablist" aria-label="Tab field notes">
        {items.map((item, i) => (
          <button
            key={item.title}
            ref={(el) => {
              refs.current[i] = el;
            }}
            role="tab"
            id={`${id}-t${i}`}
            aria-selected={active === i}
            aria-controls={`${id}-p${i}`}
            tabIndex={i === active ? 0 : -1}
            onFocus={() => set(i)}
            onClick={() => set(i)}
            onKeyDown={(e) => {
              const next = (
                {
                  ArrowRight: (i + 1) % items.length,
                  ArrowLeft: (i + items.length - 1) % items.length,
                  Home: 0,
                  End: items.length - 1,
                } as Record<string, number | undefined>
              )[e.key];
              if (next !== undefined) {
                e.preventDefault();
                refs.current[next]?.focus();
              }
            }}
          >
            {item.title}
          </button>
        ))}
      </div>
      {items.map((item, i) => (
        <div
          key={item.title}
          role="tabpanel"
          id={`${id}-p${i}`}
          aria-labelledby={`${id}-t${i}`}
          hidden={active !== i}
          tabIndex={0}
        >
          {item.body}
        </div>
      ))}
    </>
  );
}
