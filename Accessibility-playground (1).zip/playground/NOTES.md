# Interaction Atlas — implementation review

## What each specimen guarantees

- **Modal:** `src/Dialog.tsx` uses the native `<dialog>` element and `showModal()` to make the rest of the document inert. The title and description are linked by ID. Opening places focus on Close; Tab and Shift+Tab wrap at the two controls. Native Escape dismissal and either button reach the same close handler, which restores focus to the opener.
- **Tabs:** `src/Tabs.tsx` implements horizontal automatic activation because every panel is already present locally. Only the selected tab is in the page tab sequence. Left/Right wrap; Home/End jump; Tab advances into the visible panel. The tab/panel names and controls relationships work across multiple instances because their IDs use `useId()`.
- **Disclosure:** `src/Disclosure.tsx` uses an actual button, so Enter and Space need no custom keyboard listener. `aria-expanded` and `hidden` derive from the same boolean. Focus stays on the trigger. Escape and arrow keys have no special meaning for this pattern.

## What the shadcn source handles differently

1. **Dialog content that changes.** The custom dialog’s wrap logic knows its first and last buttons. If a new input becomes the last control, the hard-coded boundary needs updating. `src/components/ui/dialog.tsx` composes `DialogPrimitive.Content` and `Close`; Radix’s underlying focus scope finds tabbable candidates during navigation rather than assuming two endpoints. The wrapper also supplies a visually hidden “Close” name for its icon-only button. These are separate responsibilities: styling the X is not what traps focus.
2. **Orientation and activation are configurable.** The hand-built tabs intentionally assume horizontal, left-to-right navigation and immediately activate on focus. The generated `src/components/ui/tabs.tsx` passes `orientation` and other root props to `TabsPrimitive.Root`. Radix supports vertical Up/Down navigation and manual activation. That matters for a slow-loading panel: arrowing across three labels need not activate three panels. Adding a vertical CSS layout to the handmade version alone would not supply the right key behavior.

## Evidence and limits

`keyboard.mjs` drives the production build in Chromium using keyboard events only, including reverse Tab, Escape, tab-list wrapping and Space. See `keyboard-results.txt`. This is an automated keyboard check, not a student-performed manual test or a screen-reader audit. To repeat manually, start at the address bar and Tab into the opener; follow the sequences above without clicking. Repeat with the reference samples and record any difference you observe.

Sources: [APG dialog](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/), [tabs](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/), [disclosure](https://www.w3.org/WAI/ARIA/apg/patterns/disclosure/). The reference files are from the official shadcn `new-york-v4` registry (`dialog`, `tabs`, and their `button` dependency), with local import aliases and formatting. The three custom components import no component library.
