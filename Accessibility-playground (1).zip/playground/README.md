# Interaction Atlas
React + TypeScript accessibility playground. The custom specimens and shadcn reference bench are separate implementations. See NOTES.md for the review and keyboard walkthrough.

From this directory, use Node 22 LTS and run `npm ci`, then `npm run dev`. On PowerShell use `npm.cmd ci` and `npm.cmd run dev`. `npm run build` checks strict TypeScript and creates the production site.

To replay the browser checks, build and run `npx vite preview --port 4180`; in another terminal set `CHROME_PATH` to your Chrome executable and run `node keyboard.mjs`. No mouse is used by the script.

This is an assistant-generated reference. For a by-hand assessment, independently implement the three custom widgets, test your own implementation and write down what you personally missed.
